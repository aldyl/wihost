#!/bin/sh

if rpm -q intellinuxgraphics-repo;
then
    pkexec --user root dnf -y remove intellinuxgraphics-repo;
else
    true;
fi;
